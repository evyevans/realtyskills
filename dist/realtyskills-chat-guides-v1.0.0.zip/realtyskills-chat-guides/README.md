# RealtySkills chat guides

Choose one Markdown guide and attach it to your AI chat. Each guide contains the complete entry and playbook, where applicable. Provide verified facts and ask for missing inputs before drafting. Use the catalog in the full library for jurisdiction and tool requirements.
